document.addEventListener('DOMContentLoaded', () => {
    // Elements for the overlay
    const cards = document.querySelectorAll('.speaker-slider__card');
    const overlay = document.getElementById('speaker-overlay');
    const closeOverlayBtn = document.getElementById('closeOverlay');
    const overlayName = document.getElementById('overlayName');
    const overlayPosition = document.getElementById('overlayPosition');
    const overlayBio = document.getElementById('overlayBio');
    const overlayImage = document.getElementById('overlayImage');

    // Carousel Elements
    const container = document.getElementById('speakerContainer');
    const prevBtn = document.getElementById('prevBtn');
    const nextBtn = document.getElementById('nextBtn');

    // Carousel Settings
    let currentIndex = 0;
    const visibleCards = 4; // Number of cards to display at a time
    const totalCards = container.children.length; // Total number of cards

    // Function to display a set of 4 speaker cards based on currentIndex
    function updateCarousel() {
        const start = currentIndex;
        const end = start + visibleCards;

        // Loop through all cards and display only the ones within the range
        [...container.children].forEach((card, index) => {
            card.style.display = (index >= start && index < end) ? 'block' : 'none';
        });
    }

    // Function to open the overlay with fixed positioning
    function openOverlay(card) {
        // Retrieve speaker information from data attributes
        const name = card.getAttribute('data-name');
        const position = card.getAttribute('data-position');
        const bio = card.getAttribute('data-bio');
        const imageSrc = card.querySelector('img').src;

        // Update overlay content with the card data
        overlayName.textContent = name;
        overlayPosition.textContent = position;
        overlayBio.textContent = bio;
        overlayImage.src = imageSrc;

        // Display the overlay in a fixed position below the subtitle
        overlay.style.display = 'block';
        overlay.setAttribute('aria-hidden', 'false');
        closeOverlayBtn.focus(); // Focus on the close button for accessibility
    }

    // Function to close the overlay
    function closeOverlay() {
        overlay.style.display = 'none';
        overlay.setAttribute('aria-hidden', 'true');
    }

    // Event listeners to open overlay on card click
    cards.forEach(card => {
        card.addEventListener('click', () => openOverlay(card));
    });

    // Event listener to close overlay on close button click
    closeOverlayBtn.addEventListener('click', closeOverlay);

    // Close the overlay when the 'Escape' key is pressed
    document.addEventListener('keydown', (event) => {
        if (event.key === 'Escape' && overlay.style.display === 'block') {
            closeOverlay();
        }
    });

    // Carousel navigation event listeners
    prevBtn.addEventListener('click', () => {
        if (currentIndex > 0) {
            currentIndex -= visibleCards; // Move back by 4 cards
            currentIndex = Math.max(currentIndex, 0); // Ensure index doesn't go below 0
            updateCarousel();
        }
    });

    nextBtn.addEventListener('click', () => {
        if (currentIndex + visibleCards < totalCards) {
            currentIndex += visibleCards; // Move forward by 4 cards
            updateCarousel();
        }
    });

    // Initial setup to display the first set of cards
    updateCarousel();
});
